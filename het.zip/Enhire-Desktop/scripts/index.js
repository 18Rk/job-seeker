const loginBtn = document.querySelector(".login-btn");
const signupBtn = document.querySelector(".signup-btn");

loginBtn.addEventListener("click", function (e) {
  window.location.href = "login.html";
});

signupBtn.addEventListener("click", function (e) {
  window.location.href = "signup.html";
});
