<?php
session_start();

$c = mysqli_connect('localhost', 'root', '', 'doc');

if(isset($_POST["email"]) && isset($_POST["pass"])) {
    $email = $_POST["email"];
    $pass = $_POST["pass"];

    $q = "SELECT * FROM `doc` WHERE `email` = '$email' AND `pass` = '$pass'";
    $result = mysqli_query($c, $q);

    if ($result && mysqli_num_rows($result) == 1) {
        // User found, set session variables and redirect to the homepage
        $row = mysqli_fetch_assoc($result);
        $_SESSION['logged_in'] = true;
        $_SESSION['email'] = $email;
        $_SESSION['user_id'] = $row['user_id']; // Assuming you have a 'user_id' field in your database

        header("Location: ../jobs.html");
        exit;
    } else {
        // Incorrect email or password
        echo '<script type="text/javascript">alert("Incorrect email or password");</script>';
    }
} else {
    // Handle the case where email and password are not set in the POST request
    echo '<script type="text/javascript">alert("Please provide both email and password");</script>';
}

mysqli_close($c);
?>
