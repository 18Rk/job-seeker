<?php
session_start();

$c = mysqli_connect('localhost', 'root', '', 'doc');

$email = $_POST["email"];
$pass = $_POST["pass"];

$q = "INSERT INTO `doc`(`email`, `pass`) VALUES ('$email', '$pass')";
$insert = mysqli_query($c, $q);

if ($insert) {

    $_SESSION['logged_in'] = true;
    $_SESSION['email'] = $email;

$user_id = $_SESSION['user_id'] = $user_id;


    header("Location: ../jobs.html");
    exit;
} else {
    echo '<script type="text/javascript">alert("ERROR IN INSERTING");</script>';
}

$mysqli->close();
?>
